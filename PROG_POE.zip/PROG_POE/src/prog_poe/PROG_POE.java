/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog_poe;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class PROG_POE {

    /**
     * @param args the command line arguments
     */
    private static ArrayList<Student> students = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("********************************************");
            System.out.println("Enter (1) to launch menu or any other key to exit");

            String input = scanner.nextLine();
            if (!input.equals("1")) {
                System.out.println("Exiting application.");
                break;
            }

            displayMenu();
        }
    }
       
    private static void displayMenu() {
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student");
        System.out.println("(2) Search for a student");
        System.out.println("(3) Delete a student");
        System.out.println("(4) Print student report");
        System.out.println("(5) Exit application");

        String choice = scanner.nextLine();
        switch (choice) {
            case "1":
                captureStudent();
                break;
            case "2":
                searchStudent();
                break;
            case "3":
                deleteStudent();
                break;
            case "4":
                printStudentReport();
                break;
            case "5":
                System.out.println("Exiting application.");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void captureStudent() {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("******************************");

        System.out.print("Enter the student ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age = 0;
        while (true) {
            try {
                System.out.print("Enter the student age: ");
                age = Integer.parseInt(scanner.nextLine());
                if (age < 16) {
                    System.out.println("Invalid age. Age must be 16 or older.");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        Student newStudent = new Student(id, name, age, email, course);
        students.add(newStudent);

        System.out.println("Student has been successfully added.");
    }

    private static void searchStudent() {
        System.out.print("Enter the student ID to search: ");
        String id = scanner.nextLine();

        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println("Student found:");
                System.out.println(student);
                return;
            }
        }

        System.out.println("Student with ID " + id + " cannot be located.");
    }

    private static void deleteStudent() {
        System.out.print("Enter the student ID to delete: ");
        String id = scanner.nextLine();

        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.print("Are you sure you want to delete student " + id + " from the system? Yes (y) to delete: ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(student);
                    System.out.println("Student with ID " + id + " was deleted.");
                } else {
                    System.out.println("Student not deleted.");
                }
                return;
            }
        }

        System.out.println("Student with ID " + id + " cannot be located.");
    }

    private static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
            return;
        }

        System.out.println("STUDENT REPORT");
        System.out.println("******************************");
        for (Student student : students) {
            System.out.println(student);
        }
    }
    
}
