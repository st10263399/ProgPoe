package prog_poe;
  import java.util.ArrayList;
  import java.util.Scanner;
public class Student {

    private String id;
    private String name;
    private int age;
    private String email;
    private String course;

    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.setAge(age);
        this.email = email;
        this.course = course;
    }

    // Getter and setter methods
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 16) {
            this.age = age;
        } else {
            throw new IllegalArgumentException("Age must be 16 or older.");
        }
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    @Override
    public String toString() {
        return "Student ID: " + id + "\nStudent Name: " + name + "\nAge: " + age + "\nEmail: " + email + "\nCourse: " + course + "\n";
    }
}