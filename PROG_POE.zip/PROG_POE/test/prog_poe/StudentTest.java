/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog_poe;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class StudentTest {
    
    public StudentTest() {
    }


    @Test
    public void testConstructorAndGetters() {
        Student student = new Student("S123", "Alice Johnson", 20, "alice.johnson@example.com", "Computer Science");
        assertEquals("S123", student.getId());
        assertEquals("Alice Johnson", student.getName());
        assertEquals(20, student.getAge());
        assertEquals("alice.johnson@example.com", student.getEmail());
        assertEquals("Computer Science", student.getCourse());
    }

    @Test
    public void testSetAgeValid() {
        Student student = new Student("S123", "Alice Johnson", 20, "alice.johnson@example.com", "Computer Science");
        student.setAge(25);
        assertEquals(25, student.getAge());
    }

    @Test
    public void testSetAgeInvalid() {
        Student student = new Student("S123", "Alice Johnson", 20, "alice.johnson@example.com", "Computer Science");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            student.setAge(15);
        });
        assertEquals("Age must be 16 or older.", exception.getMessage());
    }

    @Test
    public void testToString() {
        Student student = new Student("S123", "Alice Johnson", 20, "alice.johnson@example.com", "Computer Science");
        String expectedOutput = "Student ID: S123\nStudent Name: Alice Johnson\nAge: 20\nEmail: alice.johnson@example.com\nCourse: Computer Science\n";
        assertEquals(expectedOutput, student.toString());
    }
}

    

