/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package question2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 *
 * @author lab_services_student
 */
public class GroceriesTest {

    @Test
    public void testDisplayProduct() {
        Groceries groceries = new Groceries(1, "Apple", 0.99, 10, "2024-09-10");
       
    }
}
  

