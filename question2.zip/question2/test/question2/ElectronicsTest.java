/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package question2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


/**
 *
 * @author lab_services_student
 */

public class ElectronicsTest {

    @Test
    public void testDisplayProduct() {
        Electronics electronics = new Electronics(1, "Laptop", 999.99, 10, 24);
    }
}

    

