/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package question2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class InventoryManagerTest {
    
 @Test
    public void testAddProduct() {
        InventoryManager manager = new InventoryManager();
        Product product = new Electronics(1, "Laptop", 999.99, 10, 24);
        manager.addProduct(product);
      
    }

    @Test
    public void testDeleteProduct() {
        InventoryManager manager = new InventoryManager();
        Product product = new Electronics(1, "Laptop", 999.99, 10, 24);
        manager.addProduct(product);
        manager.deleteProduct(1);
        
    }

    @Test
    public void testRecordSale() {
        InventoryManager manager = new InventoryManager();
        Product product = new Electronics(1, "Laptop", 999.99, 10, 24);
        manager.addProduct(product);
        manager.recordSale(1, 5);
        assertEquals(5, product.stockQuantity);
    }
}


    

