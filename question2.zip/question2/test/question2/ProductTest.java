/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package question2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class ProductTest {
    
    public ProductTest() {
    }

    @Test
    public void testUpdateStock() {
        Product product = new Product(1, "Test Product", 10.0, 20);
        product.updateStock(10);
        assertEquals(30, product.stockQuantity);
    }

    @Test
    public void testRecordSale() {Product product = new Product(1, "Test Product", 10.0, 20);
        product.recordSale(5);
        assertEquals(15, product.stockQuantity);
        product.recordSale(20);
        assertEquals(15, product.stockQuantity); 
    }

    @Test
    public void testDisplayProduct() {
    }

    @Test
    public void testIsLowStock() {
        Product product = new Product(1, "Test Product", 10.0, 4);
        assertTrue(product.isLowStock());
        product.updateStock(2);
        assertFalse(product.isLowStock());
    }
    
}


