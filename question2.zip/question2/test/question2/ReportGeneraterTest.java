/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package question2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 *
 * @author lab_services_student
 */
public class ReportGeneraterTest {

    @Test
    public void testGenerateReport() {
        InventoryManager manager = new InventoryManager();
        Product product = new Electronics(1, "Laptop", 999.99, 10, 24);
        manager.addProduct(product);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));

        ReportGenerater generator = new ReportGenerater();
        generator.generateReport(manager);

        String output = outputStream.toString();
        assertTrue(output.contains("Inventory Report:"));
        assertTrue(output.contains("Laptop"));
        System.setOut(originalOut);
    }
}
