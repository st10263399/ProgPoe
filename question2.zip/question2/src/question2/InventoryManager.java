
package question2;
 

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
  
     private List<Product> products;

    public InventoryManager() {
        products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void deleteProduct(int productID) {
        products.removeIf(product -> product.productID == productID);
    }

    public void recordSale(int productID, int quantity) {
        for (Product product : products) {
            if (product.productID == productID) {
                product.recordSale(quantity);
            }
        }
    }

    public void displayAllProducts() {
        for (Product product : products) {
            product.displayProduct();
        }
    }

    public void displayLowStockProducts() {
        for (Product product : products) {
            if (product.isLowStock()) {
                System.out.println("Low Stock Alert:");
                product.displayProduct();
            }
        }
    }
}

