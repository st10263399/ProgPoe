
package question2;
class Product {
    protected int productID;
    protected String name;
    protected double price;
    protected int stockQuantity;



  
    public Product(int productID, String name, double price, int stockQuantity) {
        this.productID = productID;
        this.name = name;
        this.price = price;
        this.stockQuantity = stockQuantity;
    }

    public void updateStock(int quantity) {
        this.stockQuantity += quantity;
    }

    public void recordSale(int quantity) {
        if (quantity <= stockQuantity) {
            this.stockQuantity -= quantity;
        } else {
            System.out.println("Not enough stock for " + name);
        }
    }
    public void displayProduct() {
        System.out.println("Product ID: " + productID);
        System.out.println("Name: " + name);
        System.out.println("Price: $" + price);
        System.out.println("Stock Quantity: " + stockQuantity);
        System.out.println("----------------------");
    }

    public boolean isLowStock() {
        return stockQuantity < 5;
    }
}
  



