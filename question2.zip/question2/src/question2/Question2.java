
package question2;

public class Question2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         InventoryManager inventoryManager = new InventoryManager();

        // Adding Products
        inventoryManager.addProduct(new Electronics(1, "Laptop", 999.99, 10, 24));
        inventoryManager.addProduct(new Groceries(2, "Apple", 0.99, 3, "2024-09-10"));

        // Recording a Sale
        inventoryManager.recordSale(1, 2);

        // Generate Report
        ReportGenerater reportGenerator = new ReportGenerater();
        reportGenerator.generateReport(inventoryManager);
    }
}
    

 
       