
package question2;


public class Electronics extends Product {
   // class Electronics extends Product {


    private int warrantyPeriod; // in months

    public Electronics(int productID, String name, double price, int stockQuantity, int warrantyPeriod) {
        super(productID, name, price, stockQuantity);
        this.warrantyPeriod = warrantyPeriod;
    }

    public void displayProduct() {
        super.displayProduct();
        System.out.println("Warranty Period: " + warrantyPeriod + " months");
        System.out.println("----------------------");
    }
}
