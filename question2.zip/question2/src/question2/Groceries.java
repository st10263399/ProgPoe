
package question2;


public class Groceries extends Product {
    
     
    private String expirationDate;

    public Groceries(int productID, String name, double price, int stockQuantity, String expirationDate) {
        super(productID, name, price, stockQuantity);
        this.expirationDate = expirationDate;
    }

    public void displayProduct() {
        super.displayProduct();
        System.out.println("Expiration Date: " + expirationDate);
        System.out.println("----------------------");
    }

    public boolean isExpired() {
        // Placeholder for expiration check logic
        return false;
    }
}


