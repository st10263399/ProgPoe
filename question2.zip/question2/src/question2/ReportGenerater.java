
package question2;
 

public class ReportGenerater {
 
    public void generateReport(InventoryManager inventoryManager) {
        System.out.println("Inventory Report:");
        System.out.println("======================");
        inventoryManager.displayAllProducts();
        System.out.println("Low Stock Items:");
        inventoryManager.displayLowStockProducts();
    }
}










